package com.example.springsecurity.entities;

public enum Role {

    USER, ADMIN
}
