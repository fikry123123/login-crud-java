package com.example.springsecurity.dto;

import lombok.Data;

@Data
public class SignUpRequest {

    private String firstName;
    private String LastName;
    private String email;
    private String password;
}
